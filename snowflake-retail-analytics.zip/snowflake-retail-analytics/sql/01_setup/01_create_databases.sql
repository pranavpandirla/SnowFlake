-- =====================================================
-- Snowflake Retail Analytics - Setup Script
-- Part 1: Create Databases and Schemas
-- =====================================================

-- Use ACCOUNTADMIN role for setup
USE ROLE ACCOUNTADMIN;

-- =====================================================
-- CREATE DATABASES
-- =====================================================

-- RAW Database: Landing zone for source data
CREATE DATABASE IF NOT EXISTS RETAIL_RAW
    COMMENT = 'Raw landing zone for retail data - preserves source data as-is';

-- STAGING Database: Transformation and cleansing layer
CREATE DATABASE IF NOT EXISTS RETAIL_STAGING
    COMMENT = 'Staging layer for data transformation and cleansing';

-- ANALYTICS Database: Business-ready data warehouse
CREATE DATABASE IF NOT EXISTS RETAIL_ANALYTICS
    COMMENT = 'Analytics layer - star schema for business intelligence';

-- UTILITY Database: Metadata, logs, and utilities
CREATE DATABASE IF NOT EXISTS RETAIL_UTILITY
    COMMENT = 'Utility database for metadata, logs, and helper functions';

SHOW DATABASES LIKE 'RETAIL%';

-- =====================================================
-- CREATE SCHEMAS IN RAW DATABASE
-- =====================================================

USE DATABASE RETAIL_RAW;

CREATE SCHEMA IF NOT EXISTS SOURCES
    COMMENT = 'Raw data from source systems';

CREATE SCHEMA IF NOT EXISTS ARCHIVE
    COMMENT = 'Archived historical data';

-- =====================================================
-- CREATE SCHEMAS IN STAGING DATABASE
-- =====================================================

USE DATABASE RETAIL_STAGING;

CREATE SCHEMA IF NOT EXISTS CLEANSED
    COMMENT = 'Cleansed and standardized data';

CREATE SCHEMA IF NOT EXISTS TRANSFORMED
    COMMENT = 'Transformed business logic applied';

-- =====================================================
-- CREATE SCHEMAS IN ANALYTICS DATABASE
-- =====================================================

USE DATABASE RETAIL_ANALYTICS;

CREATE SCHEMA IF NOT EXISTS CORE
    COMMENT = 'Core dimensional model - facts and dimensions';

CREATE SCHEMA IF NOT EXISTS AGGREGATES
    COMMENT = 'Pre-aggregated tables for performance';

CREATE SCHEMA IF NOT EXISTS MARTS
    COMMENT = 'Business-specific data marts';

CREATE SCHEMA IF NOT EXISTS REPORTS
    COMMENT = 'Reporting views and tables';

-- =====================================================
-- CREATE SCHEMAS IN UTILITY DATABASE
-- =====================================================

USE DATABASE RETAIL_UTILITY;

CREATE SCHEMA IF NOT EXISTS METADATA
    COMMENT = 'Data lineage, audit trails, and metadata';

CREATE SCHEMA IF NOT EXISTS LOGS
    COMMENT = 'ETL logs and error tracking';

CREATE SCHEMA IF NOT EXISTS HELPERS
    COMMENT = 'Utility functions and procedures';

-- =====================================================
-- GRANT USAGE ON DATABASES TO SYSADMIN
-- =====================================================

GRANT USAGE ON DATABASE RETAIL_RAW TO ROLE SYSADMIN;
GRANT USAGE ON DATABASE RETAIL_STAGING TO ROLE SYSADMIN;
GRANT USAGE ON DATABASE RETAIL_ANALYTICS TO ROLE SYSADMIN;
GRANT USAGE ON DATABASE RETAIL_UTILITY TO ROLE SYSADMIN;

-- Grant all privileges to SYSADMIN
GRANT ALL PRIVILEGES ON DATABASE RETAIL_RAW TO ROLE SYSADMIN;
GRANT ALL PRIVILEGES ON DATABASE RETAIL_STAGING TO ROLE SYSADMIN;
GRANT ALL PRIVILEGES ON DATABASE RETAIL_ANALYTICS TO ROLE SYSADMIN;
GRANT ALL PRIVILEGES ON DATABASE RETAIL_UTILITY TO ROLE SYSADMIN;

-- =====================================================
-- SET DEFAULT CONTEXT
-- =====================================================

USE ROLE SYSADMIN;
USE WAREHOUSE COMPUTE_WH;
USE DATABASE RETAIL_ANALYTICS;
USE SCHEMA CORE;

SELECT 'Database and schema setup completed successfully!' AS STATUS;

-- =====================================================
-- VERIFICATION
-- =====================================================

-- Show all databases
SHOW DATABASES LIKE 'RETAIL%';

-- Show schemas in each database
SHOW SCHEMAS IN DATABASE RETAIL_RAW;
SHOW SCHEMAS IN DATABASE RETAIL_STAGING;
SHOW SCHEMAS IN DATABASE RETAIL_ANALYTICS;
SHOW SCHEMAS IN DATABASE RETAIL_UTILITY;
