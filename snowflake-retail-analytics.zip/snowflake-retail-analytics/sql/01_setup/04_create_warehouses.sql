-- =====================================================
-- Snowflake Retail Analytics - Setup Script
-- Part 3: Create Virtual Warehouses
-- =====================================================

USE ROLE ACCOUNTADMIN;

-- =====================================================
-- CREATE WAREHOUSES FOR DIFFERENT WORKLOADS
-- =====================================================

-- ETL Warehouse: For data loading and transformation
CREATE WAREHOUSE IF NOT EXISTS ETL_WH
    WAREHOUSE_SIZE = 'MEDIUM'
    AUTO_SUSPEND = 300           -- 5 minutes
    AUTO_RESUME = TRUE
    MIN_CLUSTER_COUNT = 1
    MAX_CLUSTER_COUNT = 3
    SCALING_POLICY = 'STANDARD'
    INITIALLY_SUSPENDED = TRUE
    COMMENT = 'Warehouse for ETL processes and data transformations';

-- ANALYTICS Warehouse: For BI queries and reporting
CREATE WAREHOUSE IF NOT EXISTS ANALYTICS_WH
    WAREHOUSE_SIZE = 'SMALL'
    AUTO_SUSPEND = 300           -- 5 minutes
    AUTO_RESUME = TRUE
    MIN_CLUSTER_COUNT = 1
    MAX_CLUSTER_COUNT = 2
    SCALING_POLICY = 'STANDARD'
    INITIALLY_SUSPENDED = TRUE
    COMMENT = 'Warehouse for analytics queries and BI workloads';

-- DATA SCIENCE Warehouse: For ad-hoc analysis
CREATE WAREHOUSE IF NOT EXISTS DATA_SCIENCE_WH
    WAREHOUSE_SIZE = 'LARGE'
    AUTO_SUSPEND = 600           -- 10 minutes
    AUTO_RESUME = TRUE
    MIN_CLUSTER_COUNT = 1
    MAX_CLUSTER_COUNT = 2
    SCALING_POLICY = 'ECONOMY'   -- More economical scaling
    INITIALLY_SUSPENDED = TRUE
    COMMENT = 'Warehouse for data science and ad-hoc analysis';

-- DEV Warehouse: For development and testing
CREATE WAREHOUSE IF NOT EXISTS DEV_WH
    WAREHOUSE_SIZE = 'XSMALL'
    AUTO_SUSPEND = 180           -- 3 minutes
    AUTO_RESUME = TRUE
    MIN_CLUSTER_COUNT = 1
    MAX_CLUSTER_COUNT = 1
    SCALING_POLICY = 'STANDARD'
    INITIALLY_SUSPENDED = TRUE
    COMMENT = 'Warehouse for development and testing - cost-optimized';

-- LOADING Warehouse: Dedicated for bulk data loading
CREATE WAREHOUSE IF NOT EXISTS LOADING_WH
    WAREHOUSE_SIZE = 'LARGE'
    AUTO_SUSPEND = 180           -- 3 minutes
    AUTO_RESUME = TRUE
    MIN_CLUSTER_COUNT = 1
    MAX_CLUSTER_COUNT = 1
    SCALING_POLICY = 'STANDARD'
    INITIALLY_SUSPENDED = TRUE
    COMMENT = 'Dedicated warehouse for bulk data loading operations';

SHOW WAREHOUSES;

-- =====================================================
-- GRANT WAREHOUSE PRIVILEGES TO ROLES
-- =====================================================

-- ETL_WH grants
GRANT USAGE, OPERATE ON WAREHOUSE ETL_WH TO ROLE DATA_ENGINEER_ROLE;
GRANT USAGE, OPERATE ON WAREHOUSE ETL_WH TO ROLE ETL_SERVICE_ROLE;
GRANT MONITOR ON WAREHOUSE ETL_WH TO ROLE SYSADMIN;

-- ANALYTICS_WH grants
GRANT USAGE ON WAREHOUSE ANALYTICS_WH TO ROLE DATA_ANALYST_ROLE;
GRANT USAGE ON WAREHOUSE ANALYTICS_WH TO ROLE BI_DEVELOPER_ROLE;
GRANT USAGE ON WAREHOUSE ANALYTICS_WH TO ROLE DATA_ENGINEER_ROLE;
GRANT MONITOR ON WAREHOUSE ANALYTICS_WH TO ROLE SYSADMIN;

-- DATA_SCIENCE_WH grants
GRANT USAGE, OPERATE ON WAREHOUSE DATA_SCIENCE_WH TO ROLE DATA_SCIENCE_ROLE;
GRANT USAGE ON WAREHOUSE DATA_SCIENCE_WH TO ROLE DATA_ENGINEER_ROLE;
GRANT MONITOR ON WAREHOUSE DATA_SCIENCE_WH TO ROLE SYSADMIN;

-- DEV_WH grants
GRANT USAGE ON WAREHOUSE DEV_WH TO ROLE DATA_ENGINEER_ROLE;
GRANT USAGE ON WAREHOUSE DEV_WH TO ROLE DATA_ANALYST_ROLE;
GRANT MONITOR ON WAREHOUSE DEV_WH TO ROLE SYSADMIN;

-- LOADING_WH grants
GRANT USAGE, OPERATE ON WAREHOUSE LOADING_WH TO ROLE DATA_ENGINEER_ROLE;
GRANT USAGE, OPERATE ON WAREHOUSE LOADING_WH TO ROLE ETL_SERVICE_ROLE;
GRANT MONITOR ON WAREHOUSE LOADING_WH TO ROLE SYSADMIN;

-- =====================================================
-- RESOURCE MONITORS FOR COST CONTROL
-- =====================================================

-- Create resource monitor for daily credit limit
CREATE RESOURCE MONITOR IF NOT EXISTS DAILY_LIMIT
    WITH CREDIT_QUOTA = 10           -- 10 credits per day
    FREQUENCY = DAILY
    START_TIMESTAMP = IMMEDIATELY
    TRIGGERS
        ON 75 PERCENT DO NOTIFY        -- Alert at 75%
        ON 90 PERCENT DO SUSPEND        -- Suspend at 90%
        ON 100 PERCENT DO SUSPEND_IMMEDIATE;  -- Force suspend at 100%

-- Create resource monitor for monthly limit
CREATE RESOURCE MONITOR IF NOT EXISTS MONTHLY_LIMIT
    WITH CREDIT_QUOTA = 200          -- 200 credits per month
    FREQUENCY = MONTHLY
    START_TIMESTAMP = IMMEDIATELY
    TRIGGERS
        ON 80 PERCENT DO NOTIFY
        ON 95 PERCENT DO SUSPEND
        ON 100 PERCENT DO SUSPEND_IMMEDIATE;

-- Apply resource monitors to warehouses
ALTER WAREHOUSE ETL_WH SET RESOURCE_MONITOR = DAILY_LIMIT;
ALTER WAREHOUSE ANALYTICS_WH SET RESOURCE_MONITOR = DAILY_LIMIT;
ALTER WAREHOUSE DATA_SCIENCE_WH SET RESOURCE_MONITOR = DAILY_LIMIT;
ALTER WAREHOUSE DEV_WH SET RESOURCE_MONITOR = DAILY_LIMIT;
ALTER WAREHOUSE LOADING_WH SET RESOURCE_MONITOR = DAILY_LIMIT;

SHOW RESOURCE MONITORS;

-- =====================================================
-- WAREHOUSE BEST PRACTICES DOCUMENTATION
-- =====================================================

/*
WAREHOUSE SIZING GUIDE:
-----------------------
X-Small:  1 credit/hour  - Light queries, development
Small:    2 credits/hour - Regular analytics, dashboards
Medium:   4 credits/hour - ETL, moderate transformations
Large:    8 credits/hour - Heavy ETL, complex queries
X-Large: 16 credits/hour - Bulk loading, intensive processing
2X-Large: 32 credits/hour - Rare use cases only

MULTI-CLUSTER WAREHOUSES:
-------------------------
- Use for concurrent users (> 10 users)
- STANDARD scaling: Fast response, higher cost
- ECONOMY scaling: Slower response, lower cost
- Set MAX_CLUSTER_COUNT based on peak concurrency

AUTO-SUSPEND SETTINGS:
----------------------
- Development: 60-180 seconds
- Production ETL: 300-600 seconds
- Analytics: 300-900 seconds
- Consider query patterns and SLA requirements

COST OPTIMIZATION TIPS:
-----------------------
1. Use smallest warehouse that meets SLA
2. Scale up for performance, scale out for concurrency
3. Use AUTO_SUSPEND aggressively
4. Monitor query performance and adjust
5. Use resource monitors for budget control
6. Consider clustering for large tables
7. Use result caching when possible
*/

-- =====================================================
-- VERIFICATION QUERIES
-- =====================================================

-- Check warehouse configurations
SELECT 
    NAME,
    SIZE,
    AUTO_SUSPEND,
    AUTO_RESUME,
    MIN_CLUSTER_COUNT,
    MAX_CLUSTER_COUNT,
    STATE,
    COMMENT
FROM INFORMATION_SCHEMA.WAREHOUSES
WHERE NAME LIKE '%_WH'
ORDER BY NAME;

-- Check warehouse privileges
SHOW GRANTS ON WAREHOUSE ETL_WH;
SHOW GRANTS ON WAREHOUSE ANALYTICS_WH;

-- Check resource monitors
SELECT 
    NAME,
    CREDIT_QUOTA,
    FREQUENCY,
    MONITOR_LEVEL
FROM SNOWFLAKE.ACCOUNT_USAGE.RESOURCE_MONITORS
WHERE NAME IN ('DAILY_LIMIT', 'MONTHLY_LIMIT');

-- =====================================================
-- WAREHOUSE USAGE MONITORING QUERY
-- =====================================================

-- Create view for warehouse monitoring
USE ROLE SYSADMIN;
USE DATABASE RETAIL_UTILITY;
USE SCHEMA METADATA;

CREATE OR REPLACE VIEW VW_WAREHOUSE_USAGE AS
SELECT 
    WAREHOUSE_NAME,
    DATE_TRUNC('DAY', START_TIME) AS USAGE_DATE,
    SUM(CREDITS_USED) AS TOTAL_CREDITS,
    ROUND(SUM(CREDITS_USED) * 2.5, 2) AS ESTIMATED_COST_USD,  -- $2.5 per credit (example rate)
    COUNT(DISTINCT QUERY_ID) AS TOTAL_QUERIES,
    AVG(EXECUTION_TIME / 1000) AS AVG_EXECUTION_SECONDS
FROM SNOWFLAKE.ACCOUNT_USAGE.WAREHOUSE_METERING_HISTORY
WHERE START_TIME >= DATEADD(MONTH, -3, CURRENT_TIMESTAMP())
GROUP BY WAREHOUSE_NAME, USAGE_DATE
ORDER BY USAGE_DATE DESC, TOTAL_CREDITS DESC;

-- Check recent warehouse usage
SELECT * 
FROM VW_WAREHOUSE_USAGE 
WHERE USAGE_DATE >= DATEADD(DAY, -7, CURRENT_DATE())
LIMIT 50;

SELECT 'Warehouse setup completed successfully!' AS STATUS;

-- =====================================================
-- COST ESTIMATION
-- =====================================================

SELECT 
    'Based on current configuration:' AS INFO,
    'ETL_WH (MEDIUM): ~$4/hour when running' AS ETL_COST,
    'ANALYTICS_WH (SMALL): ~$2/hour when running' AS ANALYTICS_COST,
    'DATA_SCIENCE_WH (LARGE): ~$8/hour when running' AS DS_COST,
    'DEV_WH (XSMALL): ~$1/hour when running' AS DEV_COST,
    'With AUTO_SUSPEND, actual costs will be much lower' AS NOTE;
