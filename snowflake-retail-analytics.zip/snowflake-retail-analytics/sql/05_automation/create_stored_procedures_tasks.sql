-- =====================================================
-- Snowflake Retail Analytics - Automation
-- Stored Procedures and Tasks for ETL Automation
-- =====================================================

USE ROLE DATA_ENGINEER_ROLE;
USE WAREHOUSE ETL_WH;
USE DATABASE RETAIL_ANALYTICS;
USE SCHEMA CORE;

-- =====================================================
-- STORED PROCEDURE: Load Dimension Customer (SCD Type 2)
-- =====================================================

CREATE OR REPLACE PROCEDURE SP_LOAD_DIM_CUSTOMER()
RETURNS VARCHAR
LANGUAGE SQL
AS
$$
DECLARE
    rows_inserted INTEGER DEFAULT 0;
    rows_updated INTEGER DEFAULT 0;
BEGIN
    -- Expire old records that have changed
    UPDATE RETAIL_ANALYTICS.CORE.DIM_CUSTOMER tgt
    SET 
        END_DATE = CURRENT_TIMESTAMP(),
        IS_CURRENT = FALSE,
        UPDATED_DATE = CURRENT_TIMESTAMP()
    WHERE IS_CURRENT = TRUE
      AND CUSTOMER_ID IN (
          SELECT src.CUSTOMER_ID
          FROM RETAIL_STAGING.CLEANSED.STG_CUSTOMERS src
          WHERE src.CUSTOMER_ID = tgt.CUSTOMER_ID
            AND (
                src.EMAIL != tgt.EMAIL OR
                src.PHONE != tgt.PHONE OR
                src.LOYALTY_TIER != tgt.LOYALTY_TIER OR
                src.CITY != tgt.CITY OR
                src.STATE != tgt.STATE
            )
      );
    
    rows_updated := SQLROWCOUNT;
    
    -- Insert new and changed records
    INSERT INTO RETAIL_ANALYTICS.CORE.DIM_CUSTOMER (
        CUSTOMER_ID, FIRST_NAME, LAST_NAME, FULL_NAME, EMAIL, PHONE,
        DATE_OF_BIRTH, AGE, AGE_GROUP, GENDER, ADDRESS, CITY, STATE, ZIPCODE,
        REGION, REGISTRATION_DATE, CUSTOMER_TENURE_DAYS, LOYALTY_TIER,
        LOYALTY_POINTS, PREFERRED_CONTACT, MARKETING_OPT_IN,
        EFFECTIVE_DATE, IS_CURRENT
    )
    SELECT 
        src.CUSTOMER_ID,
        src.FIRST_NAME,
        src.LAST_NAME,
        CONCAT(src.FIRST_NAME, ' ', src.LAST_NAME) AS FULL_NAME,
        src.EMAIL,
        src.PHONE,
        src.DATE_OF_BIRTH,
        DATEDIFF(YEAR, src.DATE_OF_BIRTH, CURRENT_DATE()) AS AGE,
        CASE 
            WHEN DATEDIFF(YEAR, src.DATE_OF_BIRTH, CURRENT_DATE()) < 25 THEN '18-24'
            WHEN DATEDIFF(YEAR, src.DATE_OF_BIRTH, CURRENT_DATE()) < 35 THEN '25-34'
            WHEN DATEDIFF(YEAR, src.DATE_OF_BIRTH, CURRENT_DATE()) < 50 THEN '35-49'
            WHEN DATEDIFF(YEAR, src.DATE_OF_BIRTH, CURRENT_DATE()) < 65 THEN '50-64'
            ELSE '65+'
        END AS AGE_GROUP,
        src.GENDER,
        src.ADDRESS,
        src.CITY,
        src.STATE,
        src.ZIPCODE,
        CASE 
            WHEN src.STATE IN ('NY', 'NJ', 'PA', 'MA', 'CT', 'RI', 'VT', 'NH', 'ME') THEN 'Northeast'
            WHEN src.STATE IN ('FL', 'GA', 'NC', 'SC', 'VA', 'WV', 'MD', 'DE') THEN 'Southeast'
            WHEN src.STATE IN ('OH', 'MI', 'IN', 'IL', 'WI', 'MN', 'IA', 'MO') THEN 'Midwest'
            WHEN src.STATE IN ('TX', 'OK', 'AR', 'LA', 'KS', 'NE') THEN 'South'
            ELSE 'West'
        END AS REGION,
        src.REGISTRATION_DATE,
        DATEDIFF(DAY, src.REGISTRATION_DATE, CURRENT_DATE()) AS CUSTOMER_TENURE_DAYS,
        src.LOYALTY_TIER,
        src.LOYALTY_POINTS,
        src.PREFERRED_CONTACT,
        src.MARKETING_OPT_IN,
        CURRENT_TIMESTAMP() AS EFFECTIVE_DATE,
        TRUE AS IS_CURRENT
    FROM RETAIL_STAGING.CLEANSED.STG_CUSTOMERS src
    LEFT JOIN RETAIL_ANALYTICS.CORE.DIM_CUSTOMER tgt 
        ON src.CUSTOMER_ID = tgt.CUSTOMER_ID AND tgt.IS_CURRENT = TRUE
    WHERE tgt.CUSTOMER_KEY IS NULL  -- New customers
       OR (  -- Changed customers
           src.EMAIL != tgt.EMAIL OR
           src.PHONE != tgt.PHONE OR
           src.LOYALTY_TIER != tgt.LOYALTY_TIER OR
           src.CITY != tgt.CITY OR
           src.STATE != tgt.STATE
       );
    
    rows_inserted := SQLROWCOUNT;
    
    RETURN 'Customer dimension loaded: ' || rows_inserted || ' inserted, ' || rows_updated || ' expired';
END;
$$;

-- =====================================================
-- STORED PROCEDURE: Load Fact Sales
-- =====================================================

CREATE OR REPLACE PROCEDURE SP_LOAD_FACT_SALES()
RETURNS VARCHAR
LANGUAGE SQL
AS
$$
DECLARE
    rows_inserted INTEGER DEFAULT 0;
BEGIN
    INSERT INTO RETAIL_ANALYTICS.CORE.FACT_SALES (
        TRANSACTION_ID, CUSTOMER_KEY, PRODUCT_KEY, STORE_KEY, DATE_KEY, TIME_KEY,
        PAYMENT_METHOD, TRANSACTION_TYPE, CASHIER_ID,
        QUANTITY, UNIT_PRICE, UNIT_COST, LINE_SUBTOTAL,
        DISCOUNT_AMOUNT, TAX_AMOUNT, LINE_TOTAL,
        GROSS_PROFIT, GROSS_PROFIT_MARGIN_PCT,
        LOYALTY_POINTS_EARNED, LOYALTY_POINTS_REDEEMED
    )
    SELECT 
        t.TRANSACTION_ID,
        c.CUSTOMER_KEY,
        p.PRODUCT_KEY,
        s.STORE_KEY,
        TO_NUMBER(TO_CHAR(t.TRANSACTION_DATE, 'YYYYMMDD')) AS DATE_KEY,
        TO_NUMBER(REPLACE(TO_CHAR(t.TRANSACTION_TIME, 'HH24MISS'), ':', '')) AS TIME_KEY,
        t.PAYMENT_METHOD,
        t.TRANSACTION_TYPE,
        t.CASHIER_ID,
        ti.QUANTITY,
        ti.UNIT_PRICE,
        p.COST AS UNIT_COST,
        ti.QUANTITY * ti.UNIT_PRICE AS LINE_SUBTOTAL,
        ti.DISCOUNT_AMOUNT,
        (ti.QUANTITY * ti.UNIT_PRICE - ti.DISCOUNT_AMOUNT) * 0.08 AS TAX_AMOUNT,
        ti.LINE_TOTAL,
        (ti.UNIT_PRICE - p.COST) * ti.QUANTITY AS GROSS_PROFIT,
        CASE WHEN ti.UNIT_PRICE > 0 
            THEN ((ti.UNIT_PRICE - p.COST) / ti.UNIT_PRICE) * 100 
            ELSE 0 
        END AS GROSS_PROFIT_MARGIN_PCT,
        ROUND(ti.LINE_TOTAL * 0.1) AS LOYALTY_POINTS_EARNED,
        t.LOYALTY_POINTS_REDEEMED
    FROM RETAIL_STAGING.TRANSFORMED.STG_TRANSACTIONS t
    INNER JOIN RETAIL_STAGING.TRANSFORMED.STG_TRANSACTION_ITEMS ti 
        ON t.TRANSACTION_ID = ti.TRANSACTION_ID
    INNER JOIN RETAIL_ANALYTICS.CORE.DIM_CUSTOMER c 
        ON t.CUSTOMER_ID = c.CUSTOMER_ID AND c.IS_CURRENT = TRUE
    INNER JOIN RETAIL_ANALYTICS.CORE.DIM_PRODUCT p 
        ON ti.PRODUCT_ID = p.PRODUCT_ID AND p.IS_CURRENT = TRUE
    INNER JOIN RETAIL_ANALYTICS.CORE.DIM_STORE s 
        ON t.STORE_ID = s.STORE_ID
    LEFT JOIN RETAIL_ANALYTICS.CORE.FACT_SALES f 
        ON t.TRANSACTION_ID = f.TRANSACTION_ID 
        AND ti.PRODUCT_ID = p.PRODUCT_ID
    WHERE f.SALES_KEY IS NULL;  -- Only insert new records
    
    rows_inserted := SQLROWCOUNT;
    
    RETURN 'Fact Sales loaded: ' || rows_inserted || ' rows inserted';
END;
$$;

-- =====================================================
-- STORED PROCEDURE: Refresh Daily Sales Aggregates
-- =====================================================

CREATE OR REPLACE PROCEDURE SP_REFRESH_DAILY_SALES_AGG()
RETURNS VARCHAR
LANGUAGE SQL
AS
$$
BEGIN
    -- Delete existing aggregates for the refresh period (last 7 days)
    DELETE FROM RETAIL_ANALYTICS.CORE.AGG_DAILY_SALES
    WHERE DATE_KEY >= TO_NUMBER(TO_CHAR(DATEADD(DAY, -7, CURRENT_DATE()), 'YYYYMMDD'));
    
    -- Insert fresh aggregates
    INSERT INTO RETAIL_ANALYTICS.CORE.AGG_DAILY_SALES (
        DATE_KEY, STORE_KEY, CATEGORY,
        TOTAL_TRANSACTIONS, TOTAL_CUSTOMERS, TOTAL_ITEMS_SOLD,
        GROSS_SALES, TOTAL_DISCOUNTS, TOTAL_TAX, NET_SALES,
        TOTAL_COST, GROSS_PROFIT, GROSS_MARGIN_PCT,
        AVG_TRANSACTION_VALUE, AVG_BASKET_SIZE
    )
    SELECT 
        f.DATE_KEY,
        f.STORE_KEY,
        p.CATEGORY,
        COUNT(DISTINCT f.TRANSACTION_ID) AS TOTAL_TRANSACTIONS,
        COUNT(DISTINCT f.CUSTOMER_KEY) AS TOTAL_CUSTOMERS,
        SUM(f.QUANTITY) AS TOTAL_ITEMS_SOLD,
        SUM(f.LINE_SUBTOTAL) AS GROSS_SALES,
        SUM(f.DISCOUNT_AMOUNT) AS TOTAL_DISCOUNTS,
        SUM(f.TAX_AMOUNT) AS TOTAL_TAX,
        SUM(f.LINE_TOTAL) AS NET_SALES,
        SUM(f.UNIT_COST * f.QUANTITY) AS TOTAL_COST,
        SUM(f.GROSS_PROFIT) AS GROSS_PROFIT,
        CASE WHEN SUM(f.LINE_TOTAL) > 0 
            THEN (SUM(f.GROSS_PROFIT) / SUM(f.LINE_TOTAL)) * 100 
            ELSE 0 
        END AS GROSS_MARGIN_PCT,
        AVG(f.LINE_TOTAL) AS AVG_TRANSACTION_VALUE,
        AVG(f.QUANTITY) AS AVG_BASKET_SIZE
    FROM RETAIL_ANALYTICS.CORE.FACT_SALES f
    INNER JOIN RETAIL_ANALYTICS.CORE.DIM_PRODUCT p 
        ON f.PRODUCT_KEY = p.PRODUCT_KEY
    WHERE f.DATE_KEY >= TO_NUMBER(TO_CHAR(DATEADD(DAY, -7, CURRENT_DATE()), 'YYYYMMDD'))
    GROUP BY f.DATE_KEY, f.STORE_KEY, p.CATEGORY;
    
    RETURN 'Daily sales aggregates refreshed for last 7 days';
END;
$$;

-- =====================================================
-- STORED PROCEDURE: Calculate Customer Lifetime Value
-- =====================================================

CREATE OR REPLACE PROCEDURE SP_CALCULATE_CUSTOMER_LTV()
RETURNS VARCHAR
LANGUAGE SQL
AS
$$
BEGIN
    -- Truncate and reload (could be optimized for incremental)
    TRUNCATE TABLE RETAIL_ANALYTICS.CORE.AGG_CUSTOMER_LIFETIME_VALUE;
    
    INSERT INTO RETAIL_ANALYTICS.CORE.AGG_CUSTOMER_LIFETIME_VALUE (
        CUSTOMER_KEY, FIRST_PURCHASE_DATE, LAST_PURCHASE_DATE,
        TOTAL_PURCHASES, TOTAL_ITEMS_PURCHASED,
        LIFETIME_REVENUE, LIFETIME_PROFIT,
        AVG_ORDER_VALUE, AVG_ITEMS_PER_ORDER,
        CUSTOMER_TENURE_DAYS, DAYS_SINCE_LAST_PURCHASE,
        PURCHASE_FREQUENCY_DAYS, RFM_RECENCY_SCORE,
        RFM_FREQUENCY_SCORE, RFM_MONETARY_SCORE,
        RFM_TOTAL_SCORE, CUSTOMER_SEGMENT, CHURN_RISK
    )
    WITH customer_metrics AS (
        SELECT 
            CUSTOMER_KEY,
            MIN(d.DATE) AS FIRST_PURCHASE_DATE,
            MAX(d.DATE) AS LAST_PURCHASE_DATE,
            COUNT(DISTINCT TRANSACTION_ID) AS TOTAL_PURCHASES,
            SUM(QUANTITY) AS TOTAL_ITEMS_PURCHASED,
            SUM(LINE_TOTAL) AS LIFETIME_REVENUE,
            SUM(GROSS_PROFIT) AS LIFETIME_PROFIT,
            AVG(LINE_TOTAL) AS AVG_ORDER_VALUE,
            AVG(QUANTITY) AS AVG_ITEMS_PER_ORDER,
            DATEDIFF(DAY, MIN(d.DATE), CURRENT_DATE()) AS CUSTOMER_TENURE_DAYS,
            DATEDIFF(DAY, MAX(d.DATE), CURRENT_DATE()) AS DAYS_SINCE_LAST_PURCHASE,
            CASE 
                WHEN COUNT(DISTINCT TRANSACTION_ID) > 1 
                THEN DATEDIFF(DAY, MIN(d.DATE), MAX(d.DATE)) / (COUNT(DISTINCT TRANSACTION_ID) - 1)
                ELSE NULL 
            END AS PURCHASE_FREQUENCY_DAYS
        FROM RETAIL_ANALYTICS.CORE.FACT_SALES f
        INNER JOIN RETAIL_ANALYTICS.CORE.DIM_DATE d ON f.DATE_KEY = d.DATE_KEY
        GROUP BY CUSTOMER_KEY
    ),
    rfm_scores AS (
        SELECT 
            *,
            -- Recency score (5 = most recent)
            NTILE(5) OVER (ORDER BY DAYS_SINCE_LAST_PURCHASE DESC) AS RFM_RECENCY_SCORE,
            -- Frequency score (5 = most frequent)
            NTILE(5) OVER (ORDER BY TOTAL_PURCHASES) AS RFM_FREQUENCY_SCORE,
            -- Monetary score (5 = highest value)
            NTILE(5) OVER (ORDER BY LIFETIME_REVENUE) AS RFM_MONETARY_SCORE
        FROM customer_metrics
    )
    SELECT 
        CUSTOMER_KEY,
        FIRST_PURCHASE_DATE,
        LAST_PURCHASE_DATE,
        TOTAL_PURCHASES,
        TOTAL_ITEMS_PURCHASED,
        LIFETIME_REVENUE,
        LIFETIME_PROFIT,
        AVG_ORDER_VALUE,
        AVG_ITEMS_PER_ORDER,
        CUSTOMER_TENURE_DAYS,
        DAYS_SINCE_LAST_PURCHASE,
        PURCHASE_FREQUENCY_DAYS,
        RFM_RECENCY_SCORE,
        RFM_FREQUENCY_SCORE,
        RFM_MONETARY_SCORE,
        (RFM_RECENCY_SCORE + RFM_FREQUENCY_SCORE + RFM_MONETARY_SCORE) AS RFM_TOTAL_SCORE,
        CASE 
            WHEN RFM_RECENCY_SCORE >= 4 AND RFM_FREQUENCY_SCORE >= 4 AND RFM_MONETARY_SCORE >= 4 THEN 'Champions'
            WHEN RFM_RECENCY_SCORE >= 3 AND RFM_FREQUENCY_SCORE >= 3 THEN 'Loyal Customers'
            WHEN RFM_RECENCY_SCORE >= 4 AND RFM_FREQUENCY_SCORE <= 2 THEN 'New Customers'
            WHEN RFM_RECENCY_SCORE <= 2 AND RFM_FREQUENCY_SCORE >= 3 THEN 'At Risk'
            WHEN RFM_RECENCY_SCORE <= 2 AND RFM_FREQUENCY_SCORE <= 2 THEN 'Hibernating'
            ELSE 'Need Attention'
        END AS CUSTOMER_SEGMENT,
        CASE 
            WHEN DAYS_SINCE_LAST_PURCHASE <= 30 THEN 'Low'
            WHEN DAYS_SINCE_LAST_PURCHASE <= 90 THEN 'Medium'
            ELSE 'High'
        END AS CHURN_RISK
    FROM rfm_scores;
    
    RETURN 'Customer LTV calculated for ' || SQLROWCOUNT || ' customers';
END;
$$;

-- =====================================================
-- CREATE TASKS FOR AUTOMATION
-- =====================================================

-- Task to run daily dimension loads
CREATE OR REPLACE TASK TASK_DAILY_DIMENSION_LOAD
    WAREHOUSE = ETL_WH
    SCHEDULE = 'USING CRON 0 2 * * * UTC'  -- Daily at 2 AM UTC
AS
    CALL SP_LOAD_DIM_CUSTOMER();

-- Task to load facts (depends on dimensions)
CREATE OR REPLACE TASK TASK_DAILY_FACT_LOAD
    WAREHOUSE = ETL_WH
    AFTER TASK_DAILY_DIMENSION_LOAD
AS
    CALL SP_LOAD_FACT_SALES();

-- Task to refresh aggregates (depends on facts)
CREATE OR REPLACE TASK TASK_DAILY_AGGREGATE_REFRESH
    WAREHOUSE = ETL_WH
    AFTER TASK_DAILY_FACT_LOAD
AS
    CALL SP_REFRESH_DAILY_SALES_AGG();

-- Task to calculate customer LTV (weekly)
CREATE OR REPLACE TASK TASK_WEEKLY_LTV_CALCULATION
    WAREHOUSE = ETL_WH
    SCHEDULE = 'USING CRON 0 3 * * 0 UTC'  -- Weekly on Sunday at 3 AM UTC
AS
    CALL SP_CALCULATE_CUSTOMER_LTV();

-- Resume tasks (they start in suspended state)
ALTER TASK TASK_DAILY_DIMENSION_LOAD RESUME;
ALTER TASK TASK_DAILY_FACT_LOAD RESUME;
ALTER TASK TASK_DAILY_AGGREGATE_REFRESH RESUME;
ALTER TASK TASK_WEEKLY_LTV_CALCULATION RESUME;

-- =====================================================
-- SHOW CREATED OBJECTS
-- =====================================================

SHOW PROCEDURES;
SHOW TASKS;

-- Check task status
SELECT NAME, STATE, SCHEDULE FROM INFORMATION_SCHEMA.TASKS
WHERE TASK_SCHEMA = 'CORE'
ORDER BY NAME;

SELECT 'Automation procedures and tasks created successfully!' AS STATUS;
