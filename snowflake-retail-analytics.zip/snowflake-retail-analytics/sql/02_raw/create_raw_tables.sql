-- =====================================================
-- Snowflake Retail Analytics - RAW Layer
-- Create Raw Tables for Landing Zone
-- =====================================================

USE ROLE DATA_ENGINEER_ROLE;
USE WAREHOUSE ETL_WH;
USE DATABASE RETAIL_RAW;
USE SCHEMA SOURCES;

-- =====================================================
-- RAW STORES TABLE
-- =====================================================

CREATE OR REPLACE TABLE RAW_STORES (
    STORE_ID INTEGER,
    STORE_NAME VARCHAR(200),
    CITY VARCHAR(100),
    STATE VARCHAR(2),
    ZIPCODE VARCHAR(10),
    STORE_SIZE_SQFT INTEGER,
    STORE_TYPE VARCHAR(50),
    OPENING_DATE DATE,
    MANAGER VARCHAR(100),
    PHONE VARCHAR(20),
    -- Metadata columns
    LOAD_TIMESTAMP TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    SOURCE_FILE VARCHAR(500),
    RECORD_HASH VARCHAR(64)
)
COMMENT = 'Raw stores data from source systems';

-- =====================================================
-- RAW CUSTOMERS TABLE
-- =====================================================

CREATE OR REPLACE TABLE RAW_CUSTOMERS (
    CUSTOMER_ID INTEGER,
    FIRST_NAME VARCHAR(100),
    LAST_NAME VARCHAR(100),
    EMAIL VARCHAR(255),
    PHONE VARCHAR(20),
    DATE_OF_BIRTH DATE,
    GENDER VARCHAR(1),
    ADDRESS VARCHAR(500),
    CITY VARCHAR(100),
    STATE VARCHAR(2),
    ZIPCODE VARCHAR(10),
    REGISTRATION_DATE DATE,
    LOYALTY_TIER VARCHAR(20),
    LOYALTY_POINTS INTEGER,
    PREFERRED_CONTACT VARCHAR(20),
    MARKETING_OPT_IN BOOLEAN,
    -- Metadata columns
    LOAD_TIMESTAMP TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    SOURCE_FILE VARCHAR(500),
    RECORD_HASH VARCHAR(64)
)
COMMENT = 'Raw customer data from source systems';

-- =====================================================
-- RAW PRODUCTS TABLE
-- =====================================================

CREATE OR REPLACE TABLE RAW_PRODUCTS (
    PRODUCT_ID INTEGER,
    PRODUCT_NAME VARCHAR(500),
    CATEGORY VARCHAR(100),
    SUBCATEGORY VARCHAR(100),
    BRAND VARCHAR(100),
    COST DECIMAL(10,2),
    PRICE DECIMAL(10,2),
    MARGIN_PCT DECIMAL(5,2),
    SUPPLIER_ID INTEGER,
    WEIGHT_LBS DECIMAL(8,2),
    DIMENSIONS VARCHAR(50),
    COLOR VARCHAR(50),
    SIZE VARCHAR(20),
    RATING DECIMAL(3,1),
    LAUNCH_DATE DATE,
    DISCONTINUED BOOLEAN,
    -- Metadata columns
    LOAD_TIMESTAMP TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    SOURCE_FILE VARCHAR(500),
    RECORD_HASH VARCHAR(64)
)
COMMENT = 'Raw product catalog data';

-- =====================================================
-- RAW TRANSACTIONS TABLE
-- =====================================================

CREATE OR REPLACE TABLE RAW_TRANSACTIONS (
    TRANSACTION_ID INTEGER,
    CUSTOMER_ID INTEGER,
    STORE_ID INTEGER,
    TRANSACTION_DATE DATE,
    TRANSACTION_TIME TIME,
    SUBTOTAL DECIMAL(12,2),
    DISCOUNT_AMOUNT DECIMAL(10,2),
    TAX_AMOUNT DECIMAL(10,2),
    TOTAL_AMOUNT DECIMAL(12,2),
    PAYMENT_METHOD VARCHAR(50),
    TRANSACTION_TYPE VARCHAR(50),
    CASHIER_ID INTEGER,
    LOYALTY_POINTS_EARNED INTEGER,
    LOYALTY_POINTS_REDEEMED INTEGER,
    -- Metadata columns
    LOAD_TIMESTAMP TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    SOURCE_FILE VARCHAR(500),
    RECORD_HASH VARCHAR(64)
)
COMMENT = 'Raw transaction header data';

-- =====================================================
-- RAW TRANSACTION ITEMS TABLE
-- =====================================================

CREATE OR REPLACE TABLE RAW_TRANSACTION_ITEMS (
    TRANSACTION_ID INTEGER,
    PRODUCT_ID INTEGER,
    QUANTITY INTEGER,
    UNIT_PRICE DECIMAL(10,2),
    DISCOUNT_AMOUNT DECIMAL(10,2),
    LINE_TOTAL DECIMAL(12,2),
    -- Metadata columns
    LOAD_TIMESTAMP TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    SOURCE_FILE VARCHAR(500),
    RECORD_HASH VARCHAR(64)
)
COMMENT = 'Raw transaction line items';

-- =====================================================
-- RAW INVENTORY TABLE
-- =====================================================

CREATE OR REPLACE TABLE RAW_INVENTORY (
    SNAPSHOT_DATE DATE,
    STORE_ID INTEGER,
    PRODUCT_ID INTEGER,
    QUANTITY_ON_HAND INTEGER,
    QUANTITY_RESERVED INTEGER,
    REORDER_POINT INTEGER,
    REORDER_QUANTITY INTEGER,
    LAST_RESTOCK_DATE DATE,
    WAREHOUSE_LOCATION VARCHAR(100),
    -- Metadata columns
    LOAD_TIMESTAMP TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    SOURCE_FILE VARCHAR(500),
    RECORD_HASH VARCHAR(64)
)
COMMENT = 'Raw inventory snapshot data';

-- =====================================================
-- FILE FORMATS FOR DATA LOADING
-- =====================================================

-- CSV File Format
CREATE OR REPLACE FILE FORMAT CSV_FORMAT
    TYPE = 'CSV'
    FIELD_DELIMITER = ','
    SKIP_HEADER = 1
    FIELD_OPTIONALLY_ENCLOSED_BY = '"'
    NULL_IF = ('NULL', 'null', '')
    EMPTY_FIELD_AS_NULL = TRUE
    COMPRESSION = AUTO
    ERROR_ON_COLUMN_COUNT_MISMATCH = FALSE
    COMMENT = 'Standard CSV format with header';

-- Parquet File Format (if using Parquet)
CREATE OR REPLACE FILE FORMAT PARQUET_FORMAT
    TYPE = 'PARQUET'
    COMPRESSION = SNAPPY
    COMMENT = 'Parquet format with Snappy compression';

-- JSON File Format (for semi-structured data)
CREATE OR REPLACE FILE FORMAT JSON_FORMAT
    TYPE = 'JSON'
    COMPRESSION = AUTO
    STRIP_OUTER_ARRAY = TRUE
    COMMENT = 'JSON format for semi-structured data';

SHOW FILE FORMATS;

-- =====================================================
-- INTERNAL STAGE FOR DATA LOADING
-- =====================================================

-- Create internal stage for file uploads
CREATE OR REPLACE STAGE INTERNAL_STAGE
    FILE_FORMAT = CSV_FORMAT
    COMMENT = 'Internal stage for CSV file uploads';

-- Create stage for archives
CREATE OR REPLACE STAGE ARCHIVE_STAGE
    FILE_FORMAT = CSV_FORMAT
    COMMENT = 'Archive stage for processed files';

-- =====================================================
-- EXTERNAL STAGE (if using AWS S3)
-- =====================================================

-- Note: Uncomment and configure with your S3 details
/*
CREATE OR REPLACE STAGE S3_STAGE
    URL = 's3://your-bucket-name/retail-data/'
    CREDENTIALS = (
        AWS_KEY_ID = 'your-access-key-id'
        AWS_SECRET_KEY = 'your-secret-access-key'
    )
    FILE_FORMAT = CSV_FORMAT
    COMMENT = 'External S3 stage for data files';
*/

-- Or use Storage Integration (more secure)
/*
CREATE STORAGE INTEGRATION S3_INTEGRATION
    TYPE = EXTERNAL_STAGE
    STORAGE_PROVIDER = S3
    ENABLED = TRUE
    STORAGE_AWS_ROLE_ARN = 'arn:aws:iam::your-account:role/your-role'
    STORAGE_ALLOWED_LOCATIONS = ('s3://your-bucket/retail-data/');

CREATE OR REPLACE STAGE S3_STAGE
    STORAGE_INTEGRATION = S3_INTEGRATION
    URL = 's3://your-bucket/retail-data/'
    FILE_FORMAT = CSV_FORMAT;
*/

SHOW STAGES;

-- =====================================================
-- UTILITY: DATA LOADING STORED PROCEDURE
-- =====================================================

CREATE OR REPLACE PROCEDURE SP_LOAD_RAW_TABLE(
    TABLE_NAME VARCHAR,
    STAGE_NAME VARCHAR,
    FILE_PATTERN VARCHAR
)
RETURNS VARCHAR
LANGUAGE JAVASCRIPT
AS
$$
    var table_name = TABLE_NAME;
    var stage_name = STAGE_NAME;
    var file_pattern = FILE_PATTERN;
    
    var sql_command = `
        COPY INTO ${table_name}
        FROM @${stage_name}
        PATTERN = '${file_pattern}'
        FILE_FORMAT = CSV_FORMAT
        ON_ERROR = 'CONTINUE'
        FORCE = TRUE;
    `;
    
    try {
        var stmt = snowflake.createStatement({sqlText: sql_command});
        var result = stmt.execute();
        return `Successfully loaded data into ${table_name}`;
    } catch (err) {
        return `Error loading ${table_name}: ${err}`;
    }
$$;

-- =====================================================
-- VERIFICATION
-- =====================================================

-- Show all tables in RAW database
SHOW TABLES IN SCHEMA RETAIL_RAW.SOURCES;

-- Show file formats
SHOW FILE FORMATS;

-- Show stages
SHOW STAGES;

-- Show procedures
SHOW PROCEDURES;

-- Check table structures
DESC TABLE RAW_CUSTOMERS;
DESC TABLE RAW_PRODUCTS;
DESC TABLE RAW_TRANSACTIONS;

SELECT 'RAW layer tables created successfully!' AS STATUS;

-- =====================================================
-- SAMPLE LOAD COMMANDS
-- =====================================================

-- These are examples - uncomment to use after uploading files

-- Load from internal stage
/*
COPY INTO RAW_STORES
FROM @INTERNAL_STAGE/stores.csv
FILE_FORMAT = CSV_FORMAT
ON_ERROR = 'CONTINUE';

COPY INTO RAW_CUSTOMERS
FROM @INTERNAL_STAGE/customers.csv
FILE_FORMAT = CSV_FORMAT
ON_ERROR = 'CONTINUE';

COPY INTO RAW_PRODUCTS
FROM @INTERNAL_STAGE/products.csv
FILE_FORMAT = CSV_FORMAT
ON_ERROR = 'CONTINUE';

COPY INTO RAW_TRANSACTIONS
FROM @INTERNAL_STAGE/transactions.csv
FILE_FORMAT = CSV_FORMAT
ON_ERROR = 'CONTINUE';

COPY INTO RAW_TRANSACTION_ITEMS
FROM @INTERNAL_STAGE/transaction_items.csv
FILE_FORMAT = CSV_FORMAT
ON_ERROR = 'CONTINUE';

COPY INTO RAW_INVENTORY
FROM @INTERNAL_STAGE/inventory.csv
FILE_FORMAT = CSV_FORMAT
ON_ERROR = 'CONTINUE';
*/

-- Verify loaded data
/*
SELECT 'STORES' AS TABLE_NAME, COUNT(*) AS ROW_COUNT FROM RAW_STORES
UNION ALL
SELECT 'CUSTOMERS', COUNT(*) FROM RAW_CUSTOMERS
UNION ALL
SELECT 'PRODUCTS', COUNT(*) FROM RAW_PRODUCTS
UNION ALL
SELECT 'TRANSACTIONS', COUNT(*) FROM RAW_TRANSACTIONS
UNION ALL
SELECT 'TRANSACTION_ITEMS', COUNT(*) FROM RAW_TRANSACTION_ITEMS
UNION ALL
SELECT 'INVENTORY', COUNT(*) FROM RAW_INVENTORY;
*/
