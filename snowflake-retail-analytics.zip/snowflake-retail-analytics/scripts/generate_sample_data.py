"""
Generate sample retail data for Snowflake Analytics project.
Creates customers, products, stores, transactions, and inventory data.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random
import os

# Set random seed for reproducibility
np.random.seed(42)
random.seed(42)

# Create data directory
os.makedirs('data', exist_ok=True)

def generate_stores(num_stores=50):
    """Generate store data"""
    
    states = ['CA', 'TX', 'FL', 'NY', 'IL', 'PA', 'OH', 'GA', 'NC', 'MI']
    cities = {
        'CA': ['Los Angeles', 'San Francisco', 'San Diego', 'Sacramento'],
        'TX': ['Houston', 'Dallas', 'Austin', 'San Antonio'],
        'FL': ['Miami', 'Orlando', 'Tampa', 'Jacksonville'],
        'NY': ['New York', 'Buffalo', 'Rochester', 'Albany'],
        'IL': ['Chicago', 'Springfield', 'Naperville', 'Peoria'],
        'PA': ['Philadelphia', 'Pittsburgh', 'Allentown', 'Erie'],
        'OH': ['Columbus', 'Cleveland', 'Cincinnati', 'Toledo'],
        'GA': ['Atlanta', 'Augusta', 'Savannah', 'Athens'],
        'NC': ['Charlotte', 'Raleigh', 'Greensboro', 'Durham'],
        'MI': ['Detroit', 'Grand Rapids', 'Ann Arbor', 'Lansing']
    }
    
    stores = []
    
    for i in range(1, num_stores + 1):
        state = random.choice(states)
        city = random.choice(cities[state])
        
        store = {
            'store_id': i,
            'store_name': f'{city} Store #{i}',
            'city': city,
            'state': state,
            'zipcode': f'{random.randint(10000, 99999)}',
            'store_size_sqft': random.randint(5000, 25000),
            'store_type': random.choice(['Flagship', 'Standard', 'Express']),
            'opening_date': (datetime.now() - timedelta(days=random.randint(100, 2000))).strftime('%Y-%m-%d'),
            'manager': f'Manager_{i}',
            'phone': f'{random.randint(200, 999)}-{random.randint(200, 999)}-{random.randint(1000, 9999)}'
        }
        stores.append(store)
    
    df = pd.DataFrame(stores)
    df.to_csv('data/stores.csv', index=False)
    print(f"✓ Generated {num_stores} stores")
    return df

def generate_customers(num_customers=5000):
    """Generate customer data"""
    
    first_names = ['James', 'Mary', 'John', 'Patricia', 'Robert', 'Jennifer', 'Michael', 
                   'Linda', 'William', 'Elizabeth', 'David', 'Barbara', 'Richard', 'Susan',
                   'Joseph', 'Jessica', 'Thomas', 'Sarah', 'Charles', 'Karen']
    last_names = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller',
                  'Davis', 'Rodriguez', 'Martinez', 'Hernandez', 'Lopez', 'Gonzalez',
                  'Wilson', 'Anderson', 'Thomas', 'Taylor', 'Moore', 'Jackson', 'Martin']
    
    customers = []
    
    for i in range(1, num_customers + 1):
        first_name = random.choice(first_names)
        last_name = random.choice(last_names)
        
        customer = {
            'customer_id': i,
            'first_name': first_name,
            'last_name': last_name,
            'email': f'{first_name.lower()}.{last_name.lower()}{i}@email.com',
            'phone': f'{random.randint(200, 999)}-{random.randint(200, 999)}-{random.randint(1000, 9999)}',
            'date_of_birth': (datetime.now() - timedelta(days=random.randint(6570, 25550))).strftime('%Y-%m-%d'),
            'gender': random.choice(['M', 'F', 'O']),
            'address': f'{random.randint(1, 9999)} Main St',
            'city': random.choice(['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix']),
            'state': random.choice(['NY', 'CA', 'IL', 'TX', 'AZ']),
            'zipcode': f'{random.randint(10000, 99999)}',
            'registration_date': (datetime.now() - timedelta(days=random.randint(1, 1095))).strftime('%Y-%m-%d'),
            'loyalty_tier': random.choice(['Bronze', 'Silver', 'Gold', 'Platinum']),
            'loyalty_points': random.randint(0, 10000),
            'preferred_contact': random.choice(['Email', 'Phone', 'SMS']),
            'marketing_opt_in': random.choice([True, False])
        }
        customers.append(customer)
    
    df = pd.DataFrame(customers)
    df.to_csv('data/customers.csv', index=False)
    print(f"✓ Generated {num_customers} customers")
    return df

def generate_products(num_products=500):
    """Generate product data"""
    
    categories = {
        'Electronics': ['Laptop', 'Smartphone', 'Tablet', 'Headphones', 'Smart Watch', 'Camera', 'TV', 'Speaker'],
        'Clothing': ['T-Shirt', 'Jeans', 'Dress', 'Jacket', 'Shoes', 'Sweater', 'Shirt', 'Pants'],
        'Home & Garden': ['Lamp', 'Chair', 'Table', 'Bedding', 'Cookware', 'Towels', 'Rug', 'Decor'],
        'Sports': ['Yoga Mat', 'Dumbbells', 'Running Shoes', 'Basketball', 'Tennis Racket', 'Bike', 'Weights'],
        'Books': ['Fiction', 'Non-Fiction', 'Biography', 'Science', 'History', 'Cookbook', 'Self-Help'],
        'Toys': ['Action Figure', 'Board Game', 'Puzzle', 'Doll', 'LEGO Set', 'Educational Toy'],
        'Beauty': ['Skincare', 'Makeup', 'Haircare', 'Fragrance', 'Bath Products', 'Nail Care'],
        'Grocery': ['Organic Food', 'Snacks', 'Beverages', 'Frozen Food', 'Dairy', 'Bakery']
    }
    
    products = []
    
    for i in range(1, num_products + 1):
        category = random.choice(list(categories.keys()))
        product_type = random.choice(categories[category])
        
        cost = round(random.uniform(5, 500), 2)
        price = round(cost * random.uniform(1.3, 2.5), 2)
        
        product = {
            'product_id': i,
            'product_name': f'{product_type} - Model {i}',
            'category': category,
            'subcategory': product_type,
            'brand': f'Brand_{random.randint(1, 50)}',
            'cost': cost,
            'price': price,
            'margin_pct': round(((price - cost) / price) * 100, 2),
            'supplier_id': random.randint(1, 30),
            'weight_lbs': round(random.uniform(0.1, 50), 2),
            'dimensions': f'{random.randint(5,30)}x{random.randint(5,30)}x{random.randint(5,30)}',
            'color': random.choice(['Black', 'White', 'Blue', 'Red', 'Green', 'Gray', 'Multi']),
            'size': random.choice(['XS', 'S', 'M', 'L', 'XL', 'N/A']),
            'rating': round(random.uniform(3.0, 5.0), 1),
            'launch_date': (datetime.now() - timedelta(days=random.randint(30, 1095))).strftime('%Y-%m-%d'),
            'discontinued': random.choice([False, False, False, False, True])  # 20% discontinued
        }
        products.append(product)
    
    df = pd.DataFrame(products)
    df.to_csv('data/products.csv', index=False)
    print(f"✓ Generated {num_products} products")
    return df

def generate_transactions(customers_df, products_df, stores_df, num_transactions=20000):
    """Generate transaction data"""
    
    transactions = []
    transaction_items = []
    
    start_date = datetime.now() - timedelta(days=365)
    
    for i in range(1, num_transactions + 1):
        customer_id = random.choice(customers_df['customer_id'].tolist())
        store_id = random.choice(stores_df['store_id'].tolist())
        transaction_date = start_date + timedelta(days=random.randint(0, 365))
        
        # Number of items in transaction
        num_items = random.choices([1, 2, 3, 4, 5], weights=[40, 30, 15, 10, 5])[0]
        selected_products = random.sample(products_df['product_id'].tolist(), num_items)
        
        subtotal = 0
        
        # Generate transaction items
        for product_id in selected_products:
            product_price = products_df[products_df['product_id'] == product_id]['price'].values[0]
            quantity = random.choices([1, 2, 3], weights=[70, 20, 10])[0]
            line_total = round(product_price * quantity, 2)
            subtotal += line_total
            
            transaction_items.append({
                'transaction_id': i,
                'product_id': product_id,
                'quantity': quantity,
                'unit_price': product_price,
                'discount_amount': round(line_total * random.choice([0, 0, 0, 0.05, 0.10, 0.15]), 2),
                'line_total': line_total
            })
        
        # Calculate totals
        discount = round(subtotal * random.choice([0, 0, 0, 0, 0.05, 0.10]), 2)
        tax = round((subtotal - discount) * 0.08, 2)
        total = round(subtotal - discount + tax, 2)
        
        transaction = {
            'transaction_id': i,
            'customer_id': customer_id,
            'store_id': store_id,
            'transaction_date': transaction_date.strftime('%Y-%m-%d'),
            'transaction_time': f'{random.randint(8, 21):02d}:{random.randint(0, 59):02d}:{random.randint(0, 59):02d}',
            'subtotal': subtotal,
            'discount_amount': discount,
            'tax_amount': tax,
            'total_amount': total,
            'payment_method': random.choice(['Credit Card', 'Debit Card', 'Cash', 'Mobile Pay', 'Gift Card']),
            'transaction_type': random.choice(['In-Store', 'Online', 'Mobile App']),
            'cashier_id': random.randint(1, 100) if random.random() > 0.3 else None,
            'loyalty_points_earned': int(total * 0.1),
            'loyalty_points_redeemed': random.choice([0, 0, 0, 0, 100, 200, 500])
        }
        transactions.append(transaction)
    
    # Save to CSV
    transactions_df = pd.DataFrame(transactions)
    transactions_df.to_csv('data/transactions.csv', index=False)
    print(f"✓ Generated {num_transactions} transactions")
    
    transaction_items_df = pd.DataFrame(transaction_items)
    transaction_items_df.to_csv('data/transaction_items.csv', index=False)
    print(f"✓ Generated {len(transaction_items)} transaction items")
    
    return transactions_df, transaction_items_df

def generate_inventory(products_df, stores_df):
    """Generate inventory snapshots"""
    
    inventory = []
    
    # Generate inventory for last 30 days
    for days_ago in range(30, -1, -1):
        snapshot_date = (datetime.now() - timedelta(days=days_ago)).strftime('%Y-%m-%d')
        
        for _, store in stores_df.iterrows():
            for _, product in products_df.iterrows():
                if random.random() > 0.3:  # 70% of products in each store
                    inventory.append({
                        'snapshot_date': snapshot_date,
                        'store_id': store['store_id'],
                        'product_id': product['product_id'],
                        'quantity_on_hand': random.randint(0, 200),
                        'quantity_reserved': random.randint(0, 20),
                        'reorder_point': random.randint(10, 50),
                        'reorder_quantity': random.randint(50, 200),
                        'last_restock_date': (datetime.now() - timedelta(days=random.randint(1, 60))).strftime('%Y-%m-%d'),
                        'warehouse_location': f'Aisle-{random.randint(1, 20)}-Bin-{random.randint(1, 50)}'
                    })
    
    df = pd.DataFrame(inventory)
    df.to_csv('data/inventory.csv', index=False)
    print(f"✓ Generated {len(inventory)} inventory records")
    return df

def generate_all_data():
    """Generate all datasets"""
    print("\n" + "="*60)
    print("Generating Sample Retail Data for Snowflake")
    print("="*60 + "\n")
    
    stores_df = generate_stores(50)
    customers_df = generate_customers(5000)
    products_df = generate_products(500)
    transactions_df, transaction_items_df = generate_transactions(customers_df, products_df, stores_df, 20000)
    inventory_df = generate_inventory(products_df, stores_df)
    
    print("\n" + "="*60)
    print("Data Generation Complete!")
    print("="*60)
    print("\nSummary:")
    print(f"  - Stores: {len(stores_df)} records")
    print(f"  - Customers: {len(customers_df)} records")
    print(f"  - Products: {len(products_df)} records")
    print(f"  - Transactions: {len(transactions_df)} records")
    print(f"  - Transaction Items: {len(transaction_items_df)} records")
    print(f"  - Inventory: {len(inventory_df)} records")
    print(f"\nFiles saved to: ./data/")
    print("\nNext steps:")
    print("  1. Review the generated CSV files in the data/ folder")
    print("  2. Upload files to AWS S3 or Snowflake internal stage")
    print("  3. Execute Snowflake SQL scripts to create tables and load data")
    print("  4. Run transformations and build analytics layer")
    
    return {
        'stores': stores_df,
        'customers': customers_df,
        'products': products_df,
        'transactions': transactions_df,
        'transaction_items': transaction_items_df,
        'inventory': inventory_df
    }

if __name__ == "__main__":
    generate_all_data()
