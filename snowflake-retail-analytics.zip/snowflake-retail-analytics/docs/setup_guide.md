# Snowflake Retail Analytics - Complete Setup Guide

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Snowflake Account Setup](#snowflake-account-setup)
3. [Initial Configuration](#initial-configuration)
4. [Data Generation](#data-generation)
5. [Database Setup](#database-setup)
6. [Data Loading](#data-loading)
7. [Transformation & Analytics](#transformation--analytics)
8. [Automation Setup](#automation-setup)
9. [Verification & Testing](#verification--testing)
10. [Monitoring & Optimization](#monitoring--optimization)

---

## Prerequisites

### Required Tools
- **Snowflake Account** (30-day free trial available at snowflake.com/trial)
- **Python 3.8+** for data generation
- **SnowSQL CLI** (optional but recommended)
- **Git** for version control

### Knowledge Requirements
- Basic SQL
- Understanding of data warehousing concepts
- Familiarity with dimensional modeling

### Optional Tools
- **Tableau** or **Power BI** for visualization
- **dbt** for advanced transformation orchestration
- **AWS S3** for external storage (optional)

---

## Snowflake Account Setup

### 1. Sign Up for Snowflake
1. Go to https://signup.snowflake.com/
2. Choose your cloud provider (AWS, Azure, or GCP)
3. Select your region
4. Complete registration

### 2. Login to Snowflake
1. Navigate to your account URL: `https://<account>.snowflakecomputing.com`
2. Login with your credentials
3. You'll land in the Snowflake Web UI (Snowsight)

### 3. Verify Your Role
```sql
-- Check your current role
SELECT CURRENT_ROLE();

-- You should be ACCOUNTADMIN or SYSADMIN
-- If not, ask your account admin for appropriate permissions
```

---

## Initial Configuration

### 1. Clone the Repository
```bash
git clone https://github.com/yourusername/snowflake-retail-analytics.git
cd snowflake-retail-analytics
```

### 2. Install Python Dependencies
```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install requirements
pip install -r requirements.txt
```

### 3. Install SnowSQL (Optional)
```bash
# macOS
brew install snowflake-snowsql

# Windows - Download from:
# https://docs.snowflake.com/en/user-guide/snowsql-install-config.html

# Linux
curl https://sfc-repo.snowflakecomputing.com/snowsql/bootstrap/1.2/linux_x86_64/snowsql-1.2.9-linux_x86_64.bash -o snowsql.bash
bash snowsql.bash
```

### 4. Configure SnowSQL Connection (Optional)
Edit `~/.snowsql/config`:
```ini
[connections.retail]
accountname = your_account
username = your_username
password = your_password
warehousename = COMPUTE_WH
dbname = RETAIL_ANALYTICS
schemaname = CORE
```

---

## Data Generation

### Generate Sample Data
```bash
cd scripts
python generate_sample_data.py
```

This creates:
- `data/customers.csv` (5,000 records)
- `data/products.csv` (500 records)
- `data/stores.csv` (50 records)
- `data/transactions.csv` (20,000 records)
- `data/transaction_items.csv` (~40,000 records)
- `data/inventory.csv` (~500,000 records)

---

## Database Setup

### Execute Setup Scripts in Order

#### 1. Create Databases and Schemas
```sql
-- In Snowflake Web UI or SnowSQL
USE ROLE ACCOUNTADMIN;

-- Execute script
@sql/01_setup/01_create_databases.sql
```

Or using SnowSQL:
```bash
snowsql -c retail -f sql/01_setup/01_create_databases.sql
```

#### 2. Create Roles and Access Control
```sql
@sql/01_setup/03_create_roles.sql
```

#### 3. Create Warehouses
```sql
@sql/01_setup/04_create_warehouses.sql
```

#### 4. Create Raw Tables
```sql
USE ROLE DATA_ENGINEER_ROLE;
USE WAREHOUSE ETL_WH;

@sql/02_raw/create_raw_tables.sql
```

### Verification
```sql
-- Check databases
SHOW DATABASES LIKE 'RETAIL%';

-- Check warehouses
SHOW WAREHOUSES;

-- Check roles
SHOW ROLES LIKE '%ROLE';

-- Check tables
SHOW TABLES IN DATABASE RETAIL_RAW;
```

---

## Data Loading

### Option 1: Load from Snowflake Web UI

1. Go to **Data** → **Databases** → **RETAIL_RAW** → **SOURCES**
2. Click on a table (e.g., RAW_CUSTOMERS)
3. Click **Load Data**
4. Upload the corresponding CSV file from `data/` folder
5. Select `CSV_FORMAT` as the file format
6. Click **Load**

Repeat for all tables.

### Option 2: Load Using Internal Stage

```sql
USE ROLE DATA_ENGINEER_ROLE;
USE WAREHOUSE LOADING_WH;
USE DATABASE RETAIL_RAW;
USE SCHEMA SOURCES;

-- Upload files to internal stage
-- (Use SnowSQL or Web UI to PUT files)

-- Using SnowSQL
PUT file://data/customers.csv @INTERNAL_STAGE;
PUT file://data/products.csv @INTERNAL_STAGE;
PUT file://data/stores.csv @INTERNAL_STAGE;
PUT file://data/transactions.csv @INTERNAL_STAGE;
PUT file://data/transaction_items.csv @INTERNAL_STAGE;
PUT file://data/inventory.csv @INTERNAL_STAGE;

-- Load data from stage
COPY INTO RAW_CUSTOMERS
FROM @INTERNAL_STAGE/customers.csv
FILE_FORMAT = CSV_FORMAT
ON_ERROR = 'CONTINUE';

COPY INTO RAW_PRODUCTS
FROM @INTERNAL_STAGE/products.csv
FILE_FORMAT = CSV_FORMAT
ON_ERROR = 'CONTINUE';

COPY INTO RAW_STORES
FROM @INTERNAL_STAGE/stores.csv
FILE_FORMAT = CSV_FORMAT
ON_ERROR = 'CONTINUE';

COPY INTO RAW_TRANSACTIONS
FROM @INTERNAL_STAGE/transactions.csv
FILE_FORMAT = CSV_FORMAT
ON_ERROR = 'CONTINUE';

COPY INTO RAW_TRANSACTION_ITEMS
FROM @INTERNAL_STAGE/transaction_items.csv
FILE_FORMAT = CSV_FORMAT
ON_ERROR = 'CONTINUE';

COPY INTO RAW_INVENTORY
FROM @INTERNAL_STAGE/inventory.csv
FILE_FORMAT = CSV_FORMAT
ON_ERROR = 'CONTINUE';
```

### Option 3: Load from AWS S3 (Advanced)

```sql
-- First configure external stage (see sql/01_setup/05_create_stages.sql)
-- Then load from S3

COPY INTO RAW_CUSTOMERS
FROM @S3_STAGE/customers.csv
FILE_FORMAT = CSV_FORMAT;
```

### Verify Data Load
```sql
SELECT 'RAW_CUSTOMERS' AS TABLE_NAME, COUNT(*) AS ROW_COUNT FROM RAW_CUSTOMERS
UNION ALL
SELECT 'RAW_PRODUCTS', COUNT(*) FROM RAW_PRODUCTS
UNION ALL
SELECT 'RAW_STORES', COUNT(*) FROM RAW_STORES
UNION ALL
SELECT 'RAW_TRANSACTIONS', COUNT(*) FROM RAW_TRANSACTIONS
UNION ALL
SELECT 'RAW_TRANSACTION_ITEMS', COUNT(*) FROM RAW_TRANSACTION_ITEMS
UNION ALL
SELECT 'RAW_INVENTORY', COUNT(*) FROM RAW_INVENTORY;

-- Expected results:
-- RAW_CUSTOMERS: ~5,000
-- RAW_PRODUCTS: ~500
-- RAW_STORES: ~50
-- RAW_TRANSACTIONS: ~20,000
-- RAW_TRANSACTION_ITEMS: ~40,000
-- RAW_INVENTORY: ~500,000
```

---

## Transformation & Analytics

### 1. Create Staging Tables
```sql
-- You'll need to create staging tables that clean and standardize raw data
-- Example:

CREATE OR REPLACE TABLE RETAIL_STAGING.CLEANSED.STG_CUSTOMERS AS
SELECT 
    CUSTOMER_ID,
    UPPER(TRIM(FIRST_NAME)) AS FIRST_NAME,
    UPPER(TRIM(LAST_NAME)) AS LAST_NAME,
    LOWER(TRIM(EMAIL)) AS EMAIL,
    PHONE,
    DATE_OF_BIRTH,
    GENDER,
    ADDRESS,
    CITY,
    STATE,
    ZIPCODE,
    REGISTRATION_DATE,
    LOYALTY_TIER,
    LOYALTY_POINTS,
    PREFERRED_CONTACT,
    MARKETING_OPT_IN
FROM RETAIL_RAW.SOURCES.RAW_CUSTOMERS
WHERE CUSTOMER_ID IS NOT NULL
  AND EMAIL IS NOT NULL;
```

### 2. Create Dimensions and Facts
```sql
@sql/04_analytics/create_dimensions_facts.sql
```

### 3. Populate Date Dimension
```sql
-- Generate dates for 5 years (2020-2025)
INSERT INTO RETAIL_ANALYTICS.CORE.DIM_DATE
WITH date_range AS (
    SELECT 
        DATEADD(DAY, SEQ4(), '2020-01-01'::DATE) AS DATE
    FROM TABLE(GENERATOR(ROWCOUNT => 1826))  -- 5 years
)
SELECT 
    TO_NUMBER(TO_CHAR(DATE, 'YYYYMMDD')) AS DATE_KEY,
    DATE,
    YEAR(DATE) AS YEAR,
    QUARTER(DATE) AS QUARTER,
    'Q' || QUARTER(DATE) AS QUARTER_NAME,
    MONTH(DATE) AS MONTH,
    MONTHNAME(DATE) AS MONTH_NAME,
    LEFT(MONTHNAME(DATE), 3) AS MONTH_SHORT,
    WEEKOFYEAR(DATE) AS WEEK_OF_YEAR,
    DAY(DATE) AS DAY_OF_MONTH,
    DAYOFYEAR(DATE) AS DAY_OF_YEAR,
    DAYOFWEEK(DATE) AS DAY_OF_WEEK,
    DAYNAME(DATE) AS DAY_NAME,
    LEFT(DAYNAME(DATE), 3) AS DAY_SHORT,
    CASE WHEN DAYOFWEEK(DATE) IN (0, 6) THEN TRUE ELSE FALSE END AS IS_WEEKEND,
    FALSE AS IS_HOLIDAY,  -- Can be enhanced with actual holidays
    NULL AS HOLIDAY_NAME,
    YEAR(DATE) AS FISCAL_YEAR,  -- Customize based on fiscal calendar
    QUARTER(DATE) AS FISCAL_QUARTER,
    MONTH(DATE) AS FISCAL_PERIOD,
    CASE WHEN DAYOFWEEK(DATE) BETWEEN 1 AND 5 THEN TRUE ELSE FALSE END AS IS_WORKING_DAY,
    DATEADD(DAY, -DAYOFWEEK(DATE) + 1, DATE) AS WEEK_START_DATE,
    DATEADD(DAY, 7 - DAYOFWEEK(DATE), DATE) AS WEEK_END_DATE,
    DATE_TRUNC('MONTH', DATE) AS MONTH_START_DATE,
    LAST_DAY(DATE) AS MONTH_END_DATE,
    DATE_TRUNC('QUARTER', DATE) AS QUARTER_START_DATE,
    LAST_DAY(DATE, 'QUARTER') AS QUARTER_END_DATE,
    DATE_TRUNC('YEAR', DATE) AS YEAR_START_DATE,
    LAST_DAY(DATE, 'YEAR') AS YEAR_END_DATE
FROM date_range;
```

### 4. Load Dimensions (Manual Initial Load)
```sql
-- Load stores (simple, no SCD)
INSERT INTO RETAIL_ANALYTICS.CORE.DIM_STORE (
    STORE_ID, STORE_NAME, CITY, STATE, ZIPCODE, REGION,
    DIVISION, STORE_SIZE_SQFT, STORE_SIZE_CATEGORY, STORE_TYPE,
    OPENING_DATE, MANAGER, PHONE, IS_ACTIVE
)
SELECT 
    STORE_ID,
    STORE_NAME,
    CITY,
    STATE,
    ZIPCODE,
    CASE 
        WHEN STATE IN ('NY', 'NJ', 'PA', 'MA', 'CT') THEN 'Northeast'
        WHEN STATE IN ('FL', 'GA', 'NC', 'SC', 'VA') THEN 'Southeast'
        WHEN STATE IN ('OH', 'MI', 'IN', 'IL', 'WI') THEN 'Midwest'
        WHEN STATE IN ('TX', 'OK', 'AR', 'LA') THEN 'South'
        ELSE 'West'
    END AS REGION,
    'US' AS DIVISION,
    STORE_SIZE_SQFT,
    CASE 
        WHEN STORE_SIZE_SQFT < 10000 THEN 'Small'
        WHEN STORE_SIZE_SQFT < 20000 THEN 'Medium'
        ELSE 'Large'
    END AS STORE_SIZE_CATEGORY,
    STORE_TYPE,
    OPENING_DATE,
    MANAGER,
    PHONE,
    TRUE AS IS_ACTIVE
FROM RETAIL_RAW.SOURCES.RAW_STORES;

-- Use stored procedures for customer and product dimensions
CALL SP_LOAD_DIM_CUSTOMER();
```

---

## Automation Setup

### 1. Create Streams for CDC
```sql
-- Create streams on staging tables
CREATE OR REPLACE STREAM STG_CUSTOMERS_STREAM 
ON TABLE RETAIL_STAGING.CLEANSED.STG_CUSTOMERS;

CREATE OR REPLACE STREAM STG_PRODUCTS_STREAM 
ON TABLE RETAIL_STAGING.CLEANSED.STG_PRODUCTS;
```

### 2. Create Stored Procedures and Tasks
```sql
@sql/05_automation/create_stored_procedures_tasks.sql
```

### 3. Monitor Task Execution
```sql
-- View task history
SELECT *
FROM TABLE(INFORMATION_SCHEMA.TASK_HISTORY())
WHERE NAME = 'TASK_DAILY_DIMENSION_LOAD'
ORDER BY SCHEDULED_TIME DESC
LIMIT 10;

-- Check task status
SHOW TASKS;
```

---

## Verification & Testing

### Run Data Quality Checks
```sql
-- Check for duplicates in dimensions
SELECT CUSTOMER_ID, COUNT(*) 
FROM DIM_CUSTOMER 
WHERE IS_CURRENT = TRUE
GROUP BY CUSTOMER_ID 
HAVING COUNT(*) > 1;

-- Verify referential integrity
SELECT COUNT(*) AS ORPHAN_RECORDS
FROM FACT_SALES f
LEFT JOIN DIM_CUSTOMER c ON f.CUSTOMER_KEY = c.CUSTOMER_KEY
WHERE c.CUSTOMER_KEY IS NULL;

-- Check date range
SELECT 
    MIN(d.DATE) AS MIN_DATE,
    MAX(d.DATE) AS MAX_DATE,
    COUNT(DISTINCT f.DATE_KEY) AS DISTINCT_DATES
FROM FACT_SALES f
JOIN DIM_DATE d ON f.DATE_KEY = d.DATE_KEY;
```

### Sample Analytics Queries
```sql
-- Total sales by month
SELECT 
    d.YEAR,
    d.MONTH_NAME,
    COUNT(DISTINCT f.TRANSACTION_ID) AS TRANSACTIONS,
    SUM(f.LINE_TOTAL) AS TOTAL_SALES,
    SUM(f.GROSS_PROFIT) AS TOTAL_PROFIT
FROM FACT_SALES f
JOIN DIM_DATE d ON f.DATE_KEY = d.DATE_KEY
GROUP BY d.YEAR, d.MONTH, d.MONTH_NAME
ORDER BY d.YEAR, d.MONTH;

-- Top 10 customers
SELECT 
    c.FULL_NAME,
    a.LIFETIME_REVENUE,
    a.TOTAL_PURCHASES,
    a.CUSTOMER_SEGMENT
FROM AGG_CUSTOMER_LIFETIME_VALUE a
JOIN DIM_CUSTOMER c ON a.CUSTOMER_KEY = c.CUSTOMER_KEY
WHERE c.IS_CURRENT = TRUE
ORDER BY a.LIFETIME_REVENUE DESC
LIMIT 10;
```

---

## Monitoring & Optimization

### Monitor Query Performance
```sql
-- Find slow queries
SELECT 
    QUERY_ID,
    QUERY_TEXT,
    EXECUTION_TIME / 1000 AS EXECUTION_SECONDS,
    WAREHOUSE_SIZE,
    BYTES_SCANNED / 1024 / 1024 / 1024 AS GB_SCANNED
FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
WHERE START_TIME >= DATEADD(DAY, -1, CURRENT_TIMESTAMP())
  AND EXECUTION_TIME > 10000
ORDER BY EXECUTION_TIME DESC
LIMIT 20;
```

### Monitor Credit Usage
```sql
-- Credit usage by warehouse
SELECT 
    WAREHOUSE_NAME,
    SUM(CREDITS_USED) AS TOTAL_CREDITS,
    SUM(CREDITS_USED) * 2.5 AS ESTIMATED_COST_USD
FROM SNOWFLAKE.ACCOUNT_USAGE.WAREHOUSE_METERING_HISTORY
WHERE START_TIME >= DATEADD(MONTH, -1, CURRENT_TIMESTAMP())
GROUP BY WAREHOUSE_NAME
ORDER BY TOTAL_CREDITS DESC;
```

### Optimization Tips
1. **Use Clustering** on large tables
2. **Enable Result Caching** (on by default)
3. **Right-size warehouses** based on workload
4. **Use AUTO_SUSPEND** aggressively
5. **Partition large tables** using clustering keys

---

## Next Steps

1. **Connect BI Tool** (Tableau, Power BI, Looker)
2. **Implement Advanced Analytics** (forecasting, anomaly detection)
3. **Add More Data Sources**
4. **Implement dbt** for transformation orchestration
5. **Set Up Data Cataloging** with Alation or Collibra
6. **Enable Data Sharing** for external stakeholders

---

## Troubleshooting

### Common Issues

**Issue**: "Insufficient privileges"
```sql
-- Grant necessary privileges
USE ROLE ACCOUNTADMIN;
GRANT USAGE ON DATABASE RETAIL_RAW TO ROLE DATA_ENGINEER_ROLE;
```

**Issue**: "Warehouse suspended"
```sql
-- Resume warehouse
ALTER WAREHOUSE ETL_WH RESUME;
```

**Issue**: "COPY command fails"
```sql
-- Check error details
SELECT * FROM TABLE(VALIDATE(RAW_CUSTOMERS, JOB_ID => '_last'));
```

---

## Support & Resources

- **Snowflake Documentation**: https://docs.snowflake.com
- **Community**: https://community.snowflake.com
- **GitHub Issues**: [Project GitHub](https://github.com/yourusername/snowflake-retail-analytics/issues)

---

**Congratulations!** Your Snowflake Retail Analytics warehouse is now set up! 🎉
